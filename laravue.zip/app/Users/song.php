<?php

namespace App\Users;

use Illuminate\Database\Eloquent\Model;

class song extends Model
{
    //
}
